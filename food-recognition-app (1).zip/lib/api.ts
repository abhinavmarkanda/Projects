export interface ServingSize {
  amount: number
  unit: string
  grams: number
}

export interface NutritionData {
  calories: number
  fat_total_g: number
  fat_saturated_g: number
  carbs_g: number
  sugars_g: number
  fiber_g: number
  protein_g: number
  sodium_mg: number
  cholesterol_mg: number
}

export interface FoodResult {
  food_name: string
  confidence: number
  serving_size: ServingSize
  nutrition_per_serving: NutritionData
  nutrition_per_100g: NutritionData
  allergens?: string[]
  ingredients?: string[]
}

export interface ApiResponse {
  success: boolean
  data: FoodResult | FoodResult[]
  error?: string
  processing_time?: number
}

export class FoodRecognitionAPI {
  private baseUrl: string
  private timeout: number
  private maxRetries: number

  constructor() {
    this.baseUrl = process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000"
    this.timeout = 30000 // 30 seconds
    this.maxRetries = 3
  }

  private async delay(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, ms))
  }

  private validateResponse(data: any): FoodResult | FoodResult[] {
    // Handle single result
    if (data.food_name) {
      return this.validateSingleResult(data)
    }

    // Handle array of results
    if (Array.isArray(data)) {
      return data.map((item) => this.validateSingleResult(item))
    }

    throw new Error("Invalid response format")
  }

  private validateSingleResult(data: any): FoodResult {
    const required = ["food_name", "confidence", "serving_size", "nutrition_per_serving", "nutrition_per_100g"]

    for (const field of required) {
      if (!data[field]) {
        throw new Error(`Missing required field: ${field}`)
      }
    }

    return {
      food_name: data.food_name,
      confidence: Math.max(0, Math.min(1, data.confidence)),
      serving_size: data.serving_size,
      nutrition_per_serving: data.nutrition_per_serving,
      nutrition_per_100g: data.nutrition_per_100g,
      allergens: data.allergens || [],
      ingredients: data.ingredients || [],
    }
  }

  async analyzeFood(file: File, onProgress?: (progress: number) => void): Promise<FoodResult | FoodResult[]> {
    let lastError: Error | null = null

    for (let attempt = 1; attempt <= this.maxRetries; attempt++) {
      try {
        onProgress?.(10) // Starting request

        const formData = new FormData()
        formData.append("file", file)

        const controller = new AbortController()
        const timeoutId = setTimeout(() => controller.abort(), this.timeout)

        onProgress?.(30) // Request sent

        const response = await fetch(`${this.baseUrl}/predict`, {
          method: "POST",
          body: formData,
          signal: controller.signal,
          headers: {
            Accept: "application/json",
          },
        })

        clearTimeout(timeoutId)
        onProgress?.(70) // Response received

        if (!response.ok) {
          const errorText = await response.text().catch(() => "Unknown error")
          throw new Error(`API request failed (${response.status}): ${errorText}`)
        }

        const data = await response.json()
        onProgress?.(90) // Processing response

        const validatedData = this.validateResponse(data)
        onProgress?.(100) // Complete

        return validatedData
      } catch (error) {
        lastError = error instanceof Error ? error : new Error("Unknown error occurred")

        if (error instanceof Error && error.name === "AbortError") {
          throw new Error("Request timed out. Please try again.")
        }

        if (attempt < this.maxRetries) {
          const delayMs = Math.pow(2, attempt) * 1000 // Exponential backoff
          await this.delay(delayMs)
          onProgress?.(0) // Reset progress for retry
        }
      }
    }

    throw lastError || new Error("Failed to analyze food after multiple attempts")
  }

  // Mock data for development/testing
  async getMockResult(): Promise<FoodResult> {
    await this.delay(2000) // Simulate API delay

    return {
      food_name: "Chicken Biryani",
      confidence: 0.93,
      serving_size: { amount: 1, unit: "plate", grams: 350 },
      nutrition_per_serving: {
        calories: 620,
        fat_total_g: 18,
        fat_saturated_g: 5,
        carbs_g: 80,
        sugars_g: 6,
        fiber_g: 3,
        protein_g: 30,
        sodium_mg: 920,
        cholesterol_mg: 95,
      },
      nutrition_per_100g: {
        calories: 177,
        fat_total_g: 5.1,
        fat_saturated_g: 1.4,
        carbs_g: 22.9,
        sugars_g: 1.7,
        fiber_g: 0.9,
        protein_g: 8.6,
        sodium_mg: 263,
        cholesterol_mg: 27,
      },
      allergens: ["gluten", "dairy"],
      ingredients: ["rice", "chicken", "spices", "yogurt"],
    }
  }

  async getMockMultipleResults(): Promise<FoodResult[]> {
    await this.delay(2500)

    return [
      {
        food_name: "Grilled Chicken Breast",
        confidence: 0.89,
        serving_size: { amount: 1, unit: "piece", grams: 150 },
        nutrition_per_serving: {
          calories: 231,
          fat_total_g: 5,
          fat_saturated_g: 1.4,
          carbs_g: 0,
          sugars_g: 0,
          fiber_g: 0,
          protein_g: 43.5,
          sodium_mg: 104,
          cholesterol_mg: 130,
        },
        nutrition_per_100g: {
          calories: 154,
          fat_total_g: 3.3,
          fat_saturated_g: 0.9,
          carbs_g: 0,
          sugars_g: 0,
          fiber_g: 0,
          protein_g: 29,
          sodium_mg: 69,
          cholesterol_mg: 87,
        },
        allergens: [],
        ingredients: ["chicken breast", "olive oil", "herbs"],
      },
      {
        food_name: "Steamed Broccoli",
        confidence: 0.76,
        serving_size: { amount: 1, unit: "cup", grams: 100 },
        nutrition_per_serving: {
          calories: 34,
          fat_total_g: 0.4,
          fat_saturated_g: 0.1,
          carbs_g: 7,
          sugars_g: 1.5,
          fiber_g: 2.6,
          protein_g: 2.8,
          sodium_mg: 33,
          cholesterol_mg: 0,
        },
        nutrition_per_100g: {
          calories: 34,
          fat_total_g: 0.4,
          fat_saturated_g: 0.1,
          carbs_g: 7,
          sugars_g: 1.5,
          fiber_g: 2.6,
          protein_g: 2.8,
          sodium_mg: 33,
          cholesterol_mg: 0,
        },
        allergens: [],
        ingredients: ["broccoli"],
      },
    ]
  }
}

export const foodAPI = new FoodRecognitionAPI()
