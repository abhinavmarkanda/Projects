"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import type { NutritionData } from "@/lib/api"

interface EnhancedNutritionFactsProps {
  nutrition: NutritionData
  title?: string
}

export function EnhancedNutritionFacts({ nutrition, title = "Nutrition Facts" }: EnhancedNutritionFactsProps) {
  // Daily Value percentages (based on 2000 calorie diet)
  const dailyValues = {
    fat_total_g: (nutrition.fat_total_g / 65) * 100,
    fat_saturated_g: (nutrition.fat_saturated_g / 20) * 100,
    cholesterol_mg: (nutrition.cholesterol_mg / 300) * 100,
    sodium_mg: (nutrition.sodium_mg / 2300) * 100,
    carbs_g: (nutrition.carbs_g / 300) * 100,
    fiber_g: (nutrition.fiber_g / 25) * 100,
    protein_g: (nutrition.protein_g / 50) * 100,
  }

  const NutrientRow = ({
    label,
    value,
    unit,
    dailyValue,
    isSubItem = false,
    isBold = false,
  }: {
    label: string
    value: number
    unit: string
    dailyValue?: number
    isSubItem?: boolean
    isBold?: boolean
  }) => (
    <div className={`flex justify-between items-center py-1 ${isSubItem ? "pl-4 text-slate-400" : ""}`}>
      <span className={`${isBold ? "font-bold text-base" : "text-sm"} ${isSubItem ? "" : "text-slate-300"}`}>
        {label}
      </span>
      <div className="flex items-center gap-2">
        <span
          className={`${isBold ? "font-bold text-base" : "text-sm"} ${isSubItem ? "text-slate-400" : "text-slate-300"}`}
        >
          {value}
          {unit}
        </span>
        {dailyValue !== undefined && dailyValue > 0 && (
          <span className="text-xs text-slate-500 min-w-[40px] text-right">{Math.round(dailyValue)}%</span>
        )}
      </div>
    </div>
  )

  return (
    <Card className="bg-slate-800/50 border-slate-600">
      <CardHeader className="pb-3">
        <CardTitle className="text-white text-lg font-bold border-b-2 border-slate-600 pb-2">{title}</CardTitle>
      </CardHeader>

      <CardContent className="space-y-1 font-mono text-sm">
        <NutrientRow label="Calories" value={nutrition.calories} unit="" isBold={true} />

        <div className="border-t border-slate-600 pt-2 space-y-1">
          <div className="text-xs text-slate-500 text-right mb-1">% Daily Value*</div>

          <NutrientRow label="Total Fat" value={nutrition.fat_total_g} unit="g" dailyValue={dailyValues.fat_total_g} />
          <NutrientRow
            label="Saturated Fat"
            value={nutrition.fat_saturated_g}
            unit="g"
            dailyValue={dailyValues.fat_saturated_g}
            isSubItem={true}
          />

          <NutrientRow
            label="Cholesterol"
            value={nutrition.cholesterol_mg}
            unit="mg"
            dailyValue={dailyValues.cholesterol_mg}
          />

          <NutrientRow label="Sodium" value={nutrition.sodium_mg} unit="mg" dailyValue={dailyValues.sodium_mg} />

          <NutrientRow
            label="Total Carbohydrates"
            value={nutrition.carbs_g}
            unit="g"
            dailyValue={dailyValues.carbs_g}
          />
          <NutrientRow
            label="Dietary Fiber"
            value={nutrition.fiber_g}
            unit="g"
            dailyValue={dailyValues.fiber_g}
            isSubItem={true}
          />
          <NutrientRow label="Total Sugars" value={nutrition.sugars_g} unit="g" isSubItem={true} />

          <NutrientRow label="Protein" value={nutrition.protein_g} unit="g" dailyValue={dailyValues.protein_g} />
        </div>

        <div className="border-t border-slate-600 pt-2 text-xs text-slate-500">
          *Percent Daily Values are based on a 2000 calorie diet.
        </div>
      </CardContent>
    </Card>
  )
}
