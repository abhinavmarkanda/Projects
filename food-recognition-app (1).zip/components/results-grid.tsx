"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import type { FoodResult } from "@/lib/api"

interface ResultsGridProps {
  results: FoodResult[]
  selectedIndex: number
  onSelect: (index: number) => void
}

export function ResultsGrid({ results, selectedIndex, onSelect }: ResultsGridProps) {
  if (results.length <= 1) return null

  return (
    <div className="space-y-4">
      <h3 className="text-white font-medium">Multiple foods detected:</h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {results.map((result, index) => (
          <Card
            key={index}
            className={`cursor-pointer transition-all duration-200 ${
              selectedIndex === index
                ? "bg-cyan-600/20 border-cyan-500 ring-1 ring-cyan-500"
                : "bg-slate-800/50 border-slate-700 hover:bg-slate-800 hover:border-slate-600"
            }`}
            onClick={() => onSelect(index)}
          >
            <CardHeader className="pb-2">
              <CardTitle className="text-sm text-white flex items-center justify-between">
                <span className="truncate">{result.food_name}</span>
                <Badge
                  variant="secondary"
                  className={`text-xs ${
                    selectedIndex === index ? "bg-cyan-600/30 text-cyan-300" : "bg-slate-700 text-slate-300"
                  }`}
                >
                  {Math.round(result.confidence * 100)}%
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="text-xs text-slate-400 space-y-1">
                <div>{result.nutrition_per_serving.calories} cal</div>
                <div>
                  {result.serving_size.amount} {result.serving_size.unit}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
