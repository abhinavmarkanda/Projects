"use client"

import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from "recharts"
import type { NutritionData } from "@/lib/api"

interface MacroChartProps {
  nutrition: NutritionData
}

export function MacroChart({ nutrition }: MacroChartProps) {
  // Calculate calories from macronutrients
  const carbCalories = nutrition.carbs_g * 4
  const proteinCalories = nutrition.protein_g * 4
  const fatCalories = nutrition.fat_total_g * 9

  const totalMacroCalories = carbCalories + proteinCalories + fatCalories
  const actualCalories = nutrition.calories

  // Handle edge case where macro calculations don't match total calories
  const adjustmentFactor = actualCalories > 0 ? actualCalories / totalMacroCalories : 1

  const data = [
    {
      name: "Carbohydrates",
      value: Math.round(carbCalories * adjustmentFactor),
      grams: nutrition.carbs_g,
      color: "#06b6d4", // cyan-500
      percentage: Math.round(((carbCalories * adjustmentFactor) / actualCalories) * 100),
    },
    {
      name: "Protein",
      value: Math.round(proteinCalories * adjustmentFactor),
      grams: nutrition.protein_g,
      color: "#10b981", // emerald-500
      percentage: Math.round(((proteinCalories * adjustmentFactor) / actualCalories) * 100),
    },
    {
      name: "Fat",
      value: Math.round(fatCalories * adjustmentFactor),
      grams: nutrition.fat_total_g,
      color: "#f59e0b", // amber-500
      percentage: Math.round(((fatCalories * adjustmentFactor) / actualCalories) * 100),
    },
  ]

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload
      return (
        <div className="bg-slate-800 border border-slate-600 rounded-lg p-3 shadow-lg">
          <p className="text-white font-medium">{data.name}</p>
          <p className="text-slate-300 text-sm">{data.value} calories</p>
          <p className="text-slate-300 text-sm">
            {data.grams}g ({data.percentage}%)
          </p>
        </div>
      )
    }
    return null
  }

  const CustomLegend = ({ payload }: any) => {
    return (
      <div className="flex flex-wrap justify-center gap-4 mt-4">
        {payload.map((entry: any, index: number) => (
          <div key={index} className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full" style={{ backgroundColor: entry.color }} />
            <span className="text-slate-300 text-sm">
              {entry.value}: {entry.payload.grams}g
            </span>
          </div>
        ))}
      </div>
    )
  }

  return (
    <div className="w-full">
      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie data={data} cx="50%" cy="50%" innerRadius={60} outerRadius={100} paddingAngle={2} dataKey="value">
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Pie>
            <Tooltip content={<CustomTooltip />} />
            <Legend content={<CustomLegend />} />
          </PieChart>
        </ResponsiveContainer>
      </div>

      <div className="mt-4 grid grid-cols-3 gap-4 text-center">
        {data.map((macro, index) => (
          <div key={index} className="bg-slate-800/50 rounded-lg p-3">
            <div className="text-2xl font-bold text-white">{macro.percentage}%</div>
            <div className="text-sm text-slate-400">{macro.name}</div>
            <div className="text-xs text-slate-500">{macro.value} cal</div>
          </div>
        ))}
      </div>
    </div>
  )
}
