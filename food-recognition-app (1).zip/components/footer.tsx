"use client"
import { Github, Linkedin, Heart, Code } from "lucide-react"

export function Footer() {
  const currentYear = new Date().getFullYear()

  return (
    <footer className="border-t border-slate-800 bg-slate-950/80 backdrop-blur-sm">
      <div className="container mx-auto px-4 py-12 max-w-6xl">
        <div className="grid md:grid-cols-3 gap-8">
          {/* Brand Section */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <span className="text-2xl">🍽️</span>
              <span className="font-bold text-white text-xl">FoodAI</span>
            </div>
            <p className="text-slate-400 text-sm leading-relaxed">
              AI-powered food recognition and nutrition analysis. Upload photos to get instant calorie estimates and
              detailed nutrition facts.
            </p>
            <div className="flex items-center gap-2 text-slate-500 text-xs">
              <Code className="w-3 h-3" />
              <span>Built with Next.js, TypeScript & AI</span>
            </div>
          </div>

          {/* Links Section */}
          <div className="space-y-4">
            <h3 className="font-semibold text-white">Resources</h3>
            <div className="space-y-2 text-sm">
              <a href="#how-it-works" className="block text-slate-400 hover:text-cyan-400 transition-colors">
                How It Works
              </a>
              <a href="#" className="block text-slate-400 hover:text-cyan-400 transition-colors">
                Privacy Policy
              </a>
              <a href="#" className="block text-slate-400 hover:text-cyan-400 transition-colors">
                Terms of Service
              </a>
              <a href="#" className="block text-slate-400 hover:text-cyan-400 transition-colors">
                API Documentation
              </a>
            </div>
          </div>

          {/* Developer Section */}
          <div className="space-y-4">
            <h3 className="font-semibold text-white">Developer</h3>
            <div className="space-y-3">
              <a
                href="https://github.com/abhinavmarkanda"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 text-slate-400 hover:text-white transition-colors group"
              >
                <div className="p-2 rounded-lg bg-slate-800/50 group-hover:bg-slate-800 transition-colors">
                  <Github className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-sm font-medium">GitHub</div>
                  <div className="text-xs text-slate-500">@abhinavmarkanda</div>
                </div>
              </a>

              <a
                href="https://linkedin.com/in/abhinav-markanda-813984332"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 text-slate-400 hover:text-white transition-colors group"
              >
                <div className="p-2 rounded-lg bg-slate-800/50 group-hover:bg-slate-800 transition-colors">
                  <Linkedin className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-sm font-medium">LinkedIn</div>
                  <div className="text-xs text-slate-500">Professional Profile</div>
                </div>
              </a>
            </div>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="border-t border-slate-800 mt-8 pt-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2 text-slate-500 text-sm">
              <span>© {currentYear} FoodAI. Made with</span>
              <Heart className="w-4 h-4 text-red-500 fill-current" />
              <span>for better nutrition awareness.</span>
            </div>

            <div className="text-slate-500 text-xs">
              Nutrition data is estimated and should not replace professional dietary advice.
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
