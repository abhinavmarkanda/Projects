"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { X, Download, Smartphone } from "lucide-react"

export function PWAInstallPrompt() {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null)
  const [showPrompt, setShowPrompt] = useState(false)
  const [isIOS, setIsIOS] = useState(false)
  const [isStandalone, setIsStandalone] = useState(false)

  useEffect(() => {
    // Check if running as PWA
    setIsStandalone(window.matchMedia("(display-mode: standalone)").matches)

    // Check if iOS
    setIsIOS(/iPad|iPhone|iPod/.test(navigator.userAgent))

    // Handle beforeinstallprompt event
    const handler = (e: Event) => {
      e.preventDefault()
      setDeferredPrompt(e)

      // Show prompt after a delay if not dismissed before
      setTimeout(() => {
        const dismissed = localStorage.getItem("pwa-install-dismissed")
        if (!dismissed) {
          setShowPrompt(true)
        }
      }, 10000) // Show after 10 seconds
    }

    window.addEventListener("beforeinstallprompt", handler)

    return () => {
      window.removeEventListener("beforeinstallprompt", handler)
    }
  }, [])

  const handleInstall = async () => {
    if (!deferredPrompt) return

    deferredPrompt.prompt()
    const { outcome } = await deferredPrompt.userChoice

    if (outcome === "accepted") {
      console.log("PWA installed")
    }

    setDeferredPrompt(null)
    setShowPrompt(false)
  }

  const handleDismiss = () => {
    setShowPrompt(false)
    localStorage.setItem("pwa-install-dismissed", "true")
  }

  // Don't show if already installed or no prompt available
  if (isStandalone || !showPrompt || (!deferredPrompt && !isIOS)) {
    return null
  }

  return (
    <Card className="fixed bottom-4 left-4 right-4 md:left-auto md:right-4 md:max-w-sm bg-slate-900 border-slate-700 shadow-2xl z-50">
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <div className="p-2 bg-cyan-600/20 rounded-lg">
            <Smartphone className="w-5 h-5 text-cyan-400" />
          </div>

          <div className="flex-1">
            <h3 className="text-white font-medium text-sm mb-1">Install FoodAI</h3>
            <p className="text-slate-400 text-xs mb-3">
              {isIOS
                ? "Add to Home Screen for quick access and offline features"
                : "Install our app for faster access and offline features"}
            </p>

            <div className="flex gap-2">
              {isIOS ? (
                <Button
                  size="sm"
                  className="bg-cyan-600 hover:bg-cyan-700 text-xs h-8"
                  onClick={() => {
                    alert('To install: Tap the Share button in Safari, then "Add to Home Screen"')
                    handleDismiss()
                  }}
                >
                  <Download className="w-3 h-3 mr-1" />
                  How to Install
                </Button>
              ) : (
                <Button size="sm" className="bg-cyan-600 hover:bg-cyan-700 text-xs h-8" onClick={handleInstall}>
                  <Download className="w-3 h-3 mr-1" />
                  Install
                </Button>
              )}

              <Button
                size="sm"
                variant="ghost"
                className="text-slate-400 hover:text-white text-xs h-8"
                onClick={handleDismiss}
              >
                Later
              </Button>
            </div>
          </div>

          <Button
            size="sm"
            variant="ghost"
            className="p-1 h-auto text-slate-400 hover:text-white"
            onClick={handleDismiss}
          >
            <X className="w-4 h-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
