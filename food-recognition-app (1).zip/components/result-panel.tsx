"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { AlertCircle, RefreshCw } from "lucide-react"
import { MacroChart } from "@/components/macro-chart"
import { EnhancedNutritionFacts } from "@/components/enhanced-nutrition-facts"
import { NutritionUnitToggle } from "@/components/nutrition-unit-toggle"
import type { FoodResult } from "@/lib/api"

interface ResultPanelProps {
  result: FoodResult | null
  error: string | null
  onRetry: () => void
  isLoading?: boolean
  progress?: number
}

export function ResultPanel({ result, error, onRetry, isLoading = false, progress = 0 }: ResultPanelProps) {
  const [nutritionUnit, setNutritionUnit] = useState<"serving" | "100g">("serving")

  if (error) {
    return (
      <Card className="bg-slate-900/50 border-slate-700">
        <CardContent className="p-6">
          <div className="flex items-center gap-3 text-red-400 mb-4">
            <AlertCircle className="w-5 h-5" />
            <span className="font-medium">Analysis Failed</span>
          </div>
          <p className="text-slate-300 mb-4">{error}</p>
          <Button onClick={onRetry} variant="outline" size="sm" disabled={isLoading}>
            <RefreshCw className="w-4 h-4 mr-2" />
            Try Again
          </Button>
        </CardContent>
      </Card>
    )
  }

  if (isLoading) {
    return (
      <Card className="bg-slate-900/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white">Analyzing Food...</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Progress value={progress} className="w-full" />
          <p className="text-slate-400 text-sm">
            {progress < 30
              ? "Uploading image..."
              : progress < 70
                ? "Processing with AI model..."
                : progress < 90
                  ? "Calculating nutrition..."
                  : "Almost done..."}
          </p>
        </CardContent>
      </Card>
    )
  }

  if (!result) {
    return (
      <Card className="bg-slate-900/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white">Detected Foods</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-slate-400">Upload and analyze a photo to see results</p>
        </CardContent>
      </Card>
    )
  }

  const { food_name, confidence, serving_size, nutrition_per_serving, nutrition_per_100g, allergens, ingredients } =
    result
  const currentNutrition = nutritionUnit === "serving" ? nutrition_per_serving : nutrition_per_100g

  return (
    <div className="space-y-6">
      {/* Header Card */}
      <Card className="bg-slate-900/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center justify-between">
            <span>{food_name}</span>
            <Badge variant="secondary" className="bg-green-600/20 text-green-400">
              {Math.round(confidence * 100)}% confident
            </Badge>
          </CardTitle>
          <p className="text-slate-400">
            Serving size: {serving_size.amount} {serving_size.unit} ({serving_size.grams}g)
          </p>
        </CardHeader>
      </Card>

      {/* Unit Toggle */}
      <NutritionUnitToggle value={nutritionUnit} onValueChange={setNutritionUnit} />

      {/* Enhanced Nutrition Facts */}
      <EnhancedNutritionFacts
        nutrition={currentNutrition}
        title={`Nutrition Facts - ${nutritionUnit === "serving" ? "Per Serving" : "Per 100g"}`}
      />

      {/* Macro Chart */}
      <Card className="bg-slate-900/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white">Macronutrient Breakdown</CardTitle>
          <p className="text-slate-400 text-sm">
            Based on {nutritionUnit === "serving" ? "serving size" : "100g portion"}
          </p>
        </CardHeader>
        <CardContent>
          <MacroChart nutrition={currentNutrition} />
        </CardContent>
      </Card>

      {/* Ingredients & Allergens */}
      {(ingredients || allergens) && (
        <Card className="bg-slate-900/50 border-slate-700">
          <CardContent className="p-6 space-y-4">
            {ingredients && ingredients.length > 0 && (
              <div>
                <h4 className="text-white font-medium mb-2">Ingredients</h4>
                <div className="flex flex-wrap gap-2">
                  {ingredients.map((ingredient: string, index: number) => (
                    <Badge key={index} variant="outline" className="border-slate-600 text-slate-300">
                      {ingredient}
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            {allergens && allergens.length > 0 && (
              <div>
                <h4 className="text-white font-medium mb-2">Allergens</h4>
                <div className="flex flex-wrap gap-2">
                  {allergens.map((allergen: string, index: number) => (
                    <Badge key={index} variant="destructive" className="bg-red-600/20 text-red-400">
                      {allergen}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  )
}
