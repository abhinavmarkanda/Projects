"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Trash2, Clock, ImageIcon } from "lucide-react"

interface HistoryEntry {
  id: number
  name: string
  size: number
  type: string
  timestamp: string
  url: string
}

interface HistoryPanelProps {
  onSelectImage: (url: string, name: string) => void
}

export function HistoryPanel({ onSelectImage }: HistoryPanelProps) {
  const [history, setHistory] = useState<HistoryEntry[]>([])

  useEffect(() => {
    loadHistory()
  }, [])

  const loadHistory = () => {
    try {
      const stored = localStorage.getItem("foodai-history")
      if (stored) {
        setHistory(JSON.parse(stored))
      }
    } catch (err) {
      console.warn("Failed to load history:", err)
    }
  }

  const clearHistory = () => {
    localStorage.removeItem("foodai-history")
    setHistory([])
  }

  const formatDate = (timestamp: string) => {
    return new Date(timestamp).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  const formatFileSize = (bytes: number) => {
    return `${Math.round(bytes / 1024)}KB`
  }

  if (history.length === 0) {
    return (
      <Card className="bg-slate-900/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Clock className="w-5 h-5" />
            History (this device)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-slate-400 text-center py-4">No photos analyzed yet</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="bg-slate-900/50 border-slate-700">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-white flex items-center gap-2">
            <Clock className="w-5 h-5" />
            History (this device)
          </CardTitle>
          <Button
            onClick={clearHistory}
            variant="outline"
            size="sm"
            className="border-slate-600 text-slate-400 hover:text-red-400 hover:border-red-600 bg-transparent"
          >
            <Trash2 className="w-4 h-4 mr-2" />
            Clear History
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {history.map((entry) => (
          <div
            key={entry.id}
            className="flex items-center gap-3 p-3 rounded-lg bg-slate-800/50 hover:bg-slate-800 transition-colors cursor-pointer"
            onClick={() => onSelectImage(entry.url, entry.name)}
          >
            <div className="w-12 h-12 rounded-lg bg-slate-700 flex items-center justify-center flex-shrink-0">
              <ImageIcon className="w-6 h-6 text-slate-400" />
            </div>

            <div className="flex-1 min-w-0">
              <p className="text-white text-sm font-medium truncate">{entry.name}</p>
              <p className="text-slate-400 text-xs">
                {formatDate(entry.timestamp)} • {formatFileSize(entry.size)}
              </p>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  )
}
