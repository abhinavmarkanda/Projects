"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Upload, Brain, Database, BarChart3 } from "lucide-react"

export function HowItWorks() {
  const steps = [
    {
      icon: Upload,
      title: "Upload Photo",
      description: "Take or upload a clear photo of your food. Top-down shots work best for accurate recognition.",
      color: "text-cyan-400",
    },
    {
      icon: Brain,
      title: "AI Recognition",
      description: "Our MobileNet-based model analyzes the image to identify food items with confidence scores.",
      color: "text-emerald-400",
    },
    {
      icon: Database,
      title: "Nutrition Lookup",
      description: "Detected foods are matched against our comprehensive nutrition database for accurate data.",
      color: "text-amber-400",
    },
    {
      icon: BarChart3,
      title: "Results Display",
      description: "Get detailed nutrition facts, macro breakdowns, and serving size information instantly.",
      color: "text-purple-400",
    },
  ]

  return (
    <section className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-white mb-4">How It Works</h2>
        <p className="text-slate-400 max-w-2xl mx-auto">
          Our AI-powered system combines computer vision with nutritional science to provide accurate calorie and
          nutrition estimates from your food photos.
        </p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
        {steps.map((step, index) => (
          <Card key={index} className="bg-slate-900/50 border-slate-700 relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-cyan-500 to-emerald-500" />

            <CardHeader className="text-center pb-4">
              <div className="mx-auto mb-4 p-3 rounded-full bg-slate-800/50 w-fit">
                <step.icon className={`w-8 h-8 ${step.color}`} />
              </div>
              <div className="absolute top-4 right-4 w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center">
                <span className="text-slate-400 text-sm font-bold">{index + 1}</span>
              </div>
              <CardTitle className="text-white text-lg">{step.title}</CardTitle>
            </CardHeader>

            <CardContent className="pt-0">
              <p className="text-slate-400 text-sm text-center leading-relaxed">{step.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="bg-slate-900/30 border-slate-700">
        <CardContent className="p-6">
          <div className="text-center space-y-4">
            <h3 className="text-xl font-semibold text-white">Accuracy & Limitations</h3>
            <div className="grid md:grid-cols-2 gap-6 text-sm text-slate-400">
              <div>
                <h4 className="text-white font-medium mb-2">Best Results With:</h4>
                <ul className="space-y-1 list-disc list-inside">
                  <li>Clear, well-lit photos</li>
                  <li>Single food items or simple dishes</li>
                  <li>Top-down or angled shots</li>
                  <li>Visible ingredients and portions</li>
                </ul>
              </div>
              <div>
                <h4 className="text-white font-medium mb-2">Current Limitations:</h4>
                <ul className="space-y-1 list-disc list-inside">
                  <li>Estimates may vary ±20% from actual values</li>
                  <li>Complex mixed dishes are challenging</li>
                  <li>Portion sizes are approximated</li>
                  <li>Not suitable for medical dietary planning</li>
                </ul>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </section>
  )
}
