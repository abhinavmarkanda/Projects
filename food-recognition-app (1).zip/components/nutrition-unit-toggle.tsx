"use client"
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group"

interface NutritionUnitToggleProps {
  value: "serving" | "100g"
  onValueChange: (value: "serving" | "100g") => void
}

export function NutritionUnitToggle({ value, onValueChange }: NutritionUnitToggleProps) {
  return (
    <div className="flex items-center justify-center mb-4">
      <ToggleGroup
        type="single"
        value={value}
        onValueChange={(newValue) => newValue && onValueChange(newValue as "serving" | "100g")}
        className="bg-slate-800 rounded-lg p-1"
      >
        <ToggleGroupItem
          value="serving"
          className="data-[state=on]:bg-cyan-600 data-[state=on]:text-white text-slate-400 hover:text-white transition-colors"
        >
          Per Serving
        </ToggleGroupItem>
        <ToggleGroupItem
          value="100g"
          className="data-[state=on]:bg-cyan-600 data-[state=on]:text-white text-slate-400 hover:text-white transition-colors"
        >
          Per 100g
        </ToggleGroupItem>
      </ToggleGroup>
    </div>
  )
}
