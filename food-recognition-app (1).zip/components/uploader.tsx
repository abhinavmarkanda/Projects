"use client"

import type React from "react"

import { useCallback, useState, useRef } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { X, Upload, Camera, AlertCircle } from "lucide-react"

interface UploaderProps {
  onImageUpload: (file: File) => void
  uploadedImage: File | null
  onClear: () => void
  isLoading: boolean
}

export function Uploader({ onImageUpload, uploadedImage, onClear, isLoading }: UploaderProps) {
  const [dragActive, setDragActive] = useState(false)
  const [previewUrl, setPreviewUrl] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [showCamera, setShowCamera] = useState(false)
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const streamRef = useRef<MediaStream | null>(null)

  const validateFile = (file: File): string | null => {
    const validTypes = ["image/jpeg", "image/jpg", "image/png", "image/webp"]
    const maxSize = 10 * 1024 * 1024 // 10MB

    if (!validTypes.includes(file.type)) {
      return "Please upload a valid image file (JPG, PNG, or WebP)"
    }

    if (file.size > maxSize) {
      return "File size must be less than 10MB"
    }

    return null
  }

  const handleFile = useCallback(
    (file: File) => {
      const validationError = validateFile(file)
      if (validationError) {
        setError(validationError)
        return
      }

      setError(null)
      onImageUpload(file)
      const url = URL.createObjectURL(file)
      setPreviewUrl(url)

      saveToHistory(file, url)
    },
    [onImageUpload],
  )

  const saveToHistory = (file: File, url: string) => {
    try {
      const history = JSON.parse(localStorage.getItem("foodai-history") || "[]")
      const newEntry = {
        id: Date.now(),
        name: file.name,
        size: file.size,
        type: file.type,
        timestamp: new Date().toISOString(),
        url: url,
      }

      const updatedHistory = [newEntry, ...history.slice(0, 9)] // Keep last 10
      localStorage.setItem("foodai-history", JSON.stringify(updatedHistory))
    } catch (err) {
      console.warn("Failed to save to history:", err)
    }
  }

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true)
    } else if (e.type === "dragleave") {
      const rect = e.currentTarget.getBoundingClientRect()
      const x = e.clientX
      const y = e.clientY

      if (x < rect.left || x >= rect.right || y < rect.top || y >= rect.bottom) {
        setDragActive(false)
      }
    }
  }, [])

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault()
      e.stopPropagation()
      setDragActive(false)

      if (e.dataTransfer.files && e.dataTransfer.files[0]) {
        handleFile(e.dataTransfer.files[0])
      }
    },
    [handleFile],
  )

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0])
    }
  }

  const startCamera = async () => {
    try {
      setError(null)
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: "environment", // Use back camera on mobile
          width: { ideal: 1280 },
          height: { ideal: 720 },
        },
      })

      streamRef.current = stream
      if (videoRef.current) {
        videoRef.current.srcObject = stream
        setShowCamera(true)
      }
    } catch (err) {
      setError("Camera access denied or not available")
    }
  }

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop())
      streamRef.current = null
    }
    setShowCamera(false)
  }

  const capturePhoto = () => {
    if (!videoRef.current || !canvasRef.current) return

    const video = videoRef.current
    const canvas = canvasRef.current
    const context = canvas.getContext("2d")

    if (!context) return

    canvas.width = video.videoWidth
    canvas.height = video.videoHeight
    context.drawImage(video, 0, 0)

    canvas.toBlob(
      (blob) => {
        if (blob) {
          const file = new File([blob], `photo-${Date.now()}.jpg`, { type: "image/jpeg" })
          handleFile(file)
          stopCamera()
        }
      },
      "image/jpeg",
      0.8,
    )
  }

  const handleClear = () => {
    onClear()
    if (previewUrl) {
      URL.revokeObjectURL(previewUrl)
      setPreviewUrl(null)
    }
    setError(null)
    stopCamera()
  }

  const dismissError = () => {
    setError(null)
  }

  return (
    <div className="space-y-4">
      {error && (
        <Alert variant="destructive" className="bg-red-900/20 border-red-800">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription className="flex items-center justify-between">
            {error}
            <Button variant="ghost" size="sm" onClick={dismissError} className="h-auto p-1 hover:bg-red-800/20">
              <X className="h-3 w-3" />
            </Button>
          </AlertDescription>
        </Alert>
      )}

      <Card className="p-6 bg-slate-900/50 border-slate-700 backdrop-blur-sm">
        {showCamera ? (
          <div className="space-y-4">
            <div className="relative">
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-64 object-cover rounded-lg bg-slate-800"
              />
              <canvas ref={canvasRef} className="hidden" />
            </div>

            <div className="flex gap-3 justify-center">
              <Button onClick={capturePhoto} className="bg-cyan-600 hover:bg-cyan-700" disabled={isLoading}>
                <Camera className="w-4 h-4 mr-2" />
                Capture
              </Button>
              <Button
                onClick={stopCamera}
                variant="outline"
                className="border-slate-600 bg-transparent"
                disabled={isLoading}
              >
                Cancel
              </Button>
            </div>
          </div>
        ) : !uploadedImage ? (
          <div
            className={`border-2 border-dashed rounded-lg p-8 text-center transition-all duration-200 ${
              dragActive
                ? "border-cyan-400 bg-cyan-500/10 scale-[1.02]"
                : "border-slate-600 hover:border-slate-500 hover:bg-slate-800/30"
            }`}
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
          >
            <div className={`transition-transform duration-200 ${dragActive ? "scale-110" : ""}`}>
              <Upload className="w-12 h-12 text-slate-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-white mb-2">
                {dragActive ? "Drop your food photo here" : "Upload or drag a food photo"}
              </h3>
              <p className="text-slate-400 mb-6">JPG, PNG, or WebP up to 10MB</p>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Button
                asChild
                variant="outline"
                className="border-slate-600 hover:border-cyan-500 hover:text-cyan-400 transition-colors bg-transparent"
              >
                <label className="cursor-pointer">
                  <Upload className="w-4 h-4 mr-2" />
                  Choose File
                  <input
                    type="file"
                    accept="image/jpeg,image/jpg,image/png,image/webp"
                    onChange={handleFileInput}
                    className="hidden"
                    disabled={isLoading}
                  />
                </label>
              </Button>

              <Button
                onClick={startCamera}
                variant="outline"
                className="border-slate-600 hover:border-cyan-500 hover:text-cyan-400 transition-colors bg-transparent"
                disabled={isLoading}
              >
                <Camera className="w-4 h-4 mr-2" />
                Take Photo
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="relative group">
              <img
                src={previewUrl || ""}
                alt="Uploaded food"
                className="w-full h-64 object-cover rounded-lg transition-transform group-hover:scale-[1.02]"
              />
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors rounded-lg" />
              <Button
                onClick={handleClear}
                size="sm"
                variant="destructive"
                className="absolute top-2 right-2 opacity-80 hover:opacity-100 transition-opacity"
                disabled={isLoading}
              >
                <X className="w-4 h-4" />
              </Button>
            </div>

            <div className="text-center space-y-2">
              <p className="text-slate-300 text-sm">
                <strong>Tip:</strong> Clear, top-down photos of single plates work best in this prototype.
              </p>
              <div className="text-xs text-slate-400">
                File: {uploadedImage.name} ({Math.round(uploadedImage.size / 1024)}KB)
              </div>
            </div>
          </div>
        )}
      </Card>
    </div>
  )
}
