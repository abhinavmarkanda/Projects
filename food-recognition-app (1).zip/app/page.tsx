"use client"

import { useState } from "react"
import { Navbar } from "@/components/navbar"
import { Uploader } from "@/components/uploader"
import { ResultPanel } from "@/components/result-panel"
import { HowItWorks } from "@/components/how-it-works"
import { Footer } from "@/components/footer"
import { HistoryPanel } from "@/components/history-panel"
import { ResultsGrid } from "@/components/results-grid"
import { OfflineIndicator } from "@/components/offline-indicator"
import { foodAPI, type FoodResult } from "@/lib/api"

export default function Home() {
  const [uploadedImage, setUploadedImage] = useState<File | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [progress, setProgress] = useState(0)
  const [results, setResults] = useState<FoodResult[]>([])
  const [selectedResultIndex, setSelectedResultIndex] = useState(0)
  const [error, setError] = useState<string | null>(null)

  const handleImageUpload = (file: File) => {
    setUploadedImage(file)
    setResults([])
    setSelectedResultIndex(0)
    setError(null)
    setProgress(0)
  }

  const handleAnalyze = async () => {
    if (!uploadedImage) return

    setIsLoading(true)
    setError(null)
    setProgress(0)

    try {
      // Check if we should use mock data (for development)
      const useMockData = process.env.NODE_ENV === "development" && !process.env.NEXT_PUBLIC_API_URL

      let result: FoodResult | FoodResult[]

      if (useMockData) {
        // Use mock data for development
        const shouldUseMockMultiple = Math.random() > 0.5
        result = shouldUseMockMultiple ? await foodAPI.getMockMultipleResults() : await foodAPI.getMockResult()

        // Simulate progress for mock data
        for (let i = 0; i <= 100; i += 10) {
          setProgress(i)
          await new Promise((resolve) => setTimeout(resolve, 100))
        }
      } else {
        // Use real API
        result = await foodAPI.analyzeFood(uploadedImage, setProgress)
      }

      // Normalize result to array format
      const resultsArray = Array.isArray(result) ? result : [result]
      setResults(resultsArray)
      setSelectedResultIndex(0)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to analyze image")
      setResults([])
    } finally {
      setIsLoading(false)
      setProgress(0)
    }
  }

  const handleClear = () => {
    setUploadedImage(null)
    setResults([])
    setSelectedResultIndex(0)
    setError(null)
    setProgress(0)
  }

  const handleHistorySelect = (url: string, name: string) => {
    fetch(url)
      .then((res) => res.blob())
      .then((blob) => {
        const file = new File([blob], name, { type: blob.type })
        handleImageUpload(file)
      })
      .catch((err) => {
        console.warn("Failed to load from history:", err)
        setError("Failed to load image from history")
      })
  }

  const currentResult = results[selectedResultIndex] || null

  return (
    <div className="min-h-screen bg-slate-950">
      <OfflineIndicator />
      <Navbar />

      <main className="container mx-auto px-4 py-8 max-w-6xl">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">🍽️ Food Recognition & Calorie Estimator</h1>
          <p className="text-slate-400 text-lg max-w-3xl mx-auto">
            Upload or snap a meal photo → detect foods (MobileNet) → estimate calories (local db).
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 mb-16">
          <div className="space-y-6">
            <Uploader
              onImageUpload={handleImageUpload}
              uploadedImage={uploadedImage}
              onClear={handleClear}
              isLoading={isLoading}
            />

            {uploadedImage && (
              <div className="flex justify-center">
                <button
                  onClick={handleAnalyze}
                  disabled={isLoading}
                  className="bg-cyan-600 hover:bg-cyan-700 disabled:bg-cyan-800 text-white px-8 py-3 rounded-lg font-medium transition-colors flex items-center gap-2 min-w-[140px]"
                >
                  {isLoading ? (
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      <span>{progress > 0 ? `${progress}%` : "Analyzing..."}</span>
                    </div>
                  ) : (
                    "Analyze Photo"
                  )}
                </button>
              </div>
            )}

            <HistoryPanel onSelectImage={handleHistorySelect} />
          </div>

          <div className="space-y-6">
            <ResultsGrid results={results} selectedIndex={selectedResultIndex} onSelect={setSelectedResultIndex} />

            <ResultPanel
              result={currentResult}
              error={error}
              onRetry={handleAnalyze}
              isLoading={isLoading}
              progress={progress}
            />
          </div>
        </div>

        <HowItWorks />
      </main>

      <Footer />
    </div>
  )
}
