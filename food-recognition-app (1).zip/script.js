import { Chart } from "@/components/ui/chart"
// Demo data for food recognition results
const DEMO_DATA = {
  foodName: "Chicken Biryani",
  confidence: 94.2,
  servingSize: "1 cup (200g)",
  nutritionPerServing: {
    calories: 485,
    fat: "18.5g",
    carbs: "58.2g",
    protein: "24.8g",
    sodium: "892mg",
    cholesterol: "78mg",
  },
  nutritionPer100g: {
    calories: 243,
    fat: "9.3g",
    carbs: "29.1g",
    protein: "12.4g",
    sodium: "446mg",
    cholesterol: "39mg",
  },
  ingredients: [
    "Basmati Rice",
    "Chicken",
    "Onions",
    "Yogurt",
    "Ginger-Garlic Paste",
    "Biryani Masala",
    "Saffron",
    "Mint Leaves",
    "Coriander",
    "Ghee",
  ],
  allergens: ["Dairy", "Gluten"],
}

class FoodRecognitionApp {
  constructor() {
    this.currentView = "serving"
    this.chart = null
    this.cameraStream = null
    this.isCameraActive = false
    this.initializeElements()
    this.bindEvents()
  }

  initializeElements() {
    // Upload elements
    this.uploadArea = document.getElementById("uploadArea")
    this.uploadBtn = document.getElementById("uploadBtn")
    this.cameraBtn = document.getElementById("cameraBtn")
    this.fileInput = document.getElementById("fileInput")
    this.imagePreview = document.getElementById("imagePreview")
    this.previewImg = document.getElementById("previewImg")
    this.clearBtn = document.getElementById("clearBtn")
    this.analyzeBtn = document.getElementById("analyzeBtn")

    this.miniPreview = document.getElementById("miniPreview")
    this.miniPreviewImg = document.getElementById("miniPreviewImg")

    this.cameraVideo = document.getElementById("cameraVideo")
    this.cameraCanvas = document.getElementById("cameraCanvas")

    this.progressContainer = document.getElementById("progressContainer")
    this.progressFill = document.getElementById("progressFill")
    this.progressText = document.getElementById("progressText")

    // Result elements
    this.resultsSection = document.getElementById("resultsSection")
    this.errorSection = document.getElementById("errorSection")
    this.foodName = document.getElementById("foodName")
    this.confidenceScore = document.getElementById("confidenceScore")
    this.servingSize = document.getElementById("servingSize")

    // Nutrition elements
    this.nutritionGrid = document.getElementById("nutritionGrid")
    this.toggleBtns = document.querySelectorAll(".toggle-btn")
    this.macroChart = document.getElementById("macroChart")

    // Additional info elements
    this.ingredientsTags = document.getElementById("ingredientsTags")
    this.allergensTags = document.getElementById("allergensTags")

    // Error elements
    this.errorMessage = document.getElementById("errorMessage")
    this.retryBtn = document.getElementById("retryBtn")
  }

  bindEvents() {
    // Upload events
    this.uploadArea.addEventListener("click", () => this.fileInput.click())
    this.uploadBtn.addEventListener("click", () => this.fileInput.click())
    this.cameraBtn.addEventListener("click", () => this.toggleCamera())
    this.fileInput.addEventListener("change", (e) => this.handleFileSelect(e))
    this.clearBtn.addEventListener("click", () => this.clearImage())
    this.analyzeBtn.addEventListener("click", () => this.analyzeImage())

    // Drag and drop events
    this.uploadArea.addEventListener("dragover", (e) => this.handleDragOver(e))
    this.uploadArea.addEventListener("dragleave", (e) => this.handleDragLeave(e))
    this.uploadArea.addEventListener("drop", (e) => this.handleDrop(e))

    // Toggle events
    this.toggleBtns.forEach((btn) => {
      btn.addEventListener("click", (e) => this.toggleNutritionView(e))
    })

    // Retry event
    this.retryBtn.addEventListener("click", () => this.analyzeImage())

    this.cameraVideo.addEventListener("click", () => this.capturePhoto())
  }

  async toggleCamera() {
    if (this.isCameraActive) {
      this.stopCamera()
    } else {
      await this.startCamera()
    }
  }

  async startCamera() {
    try {
      this.cameraStream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: "environment", // Use back camera on mobile
          width: { ideal: 1280 },
          height: { ideal: 720 },
        },
      })

      this.cameraVideo.srcObject = this.cameraStream
      this.cameraVideo.style.display = "block"
      this.cameraBtn.textContent = "Capture Photo"
      this.cameraBtn.style.background = "linear-gradient(135deg, #ef4444, #dc2626)"
      this.isCameraActive = true

      // Hide file input area when camera is active
      this.uploadArea.style.display = "none"
    } catch (error) {
      console.error("Error accessing camera:", error)
      this.showError("Unable to access camera. Please check permissions or use file upload instead.")
    }
  }

  stopCamera() {
    if (this.cameraStream) {
      this.cameraStream.getTracks().forEach((track) => track.stop())
      this.cameraStream = null
    }

    this.cameraVideo.style.display = "none"
    this.cameraBtn.textContent = "Take Photo"
    this.cameraBtn.style.background = "linear-gradient(135deg, #a855f7, #ec4899, #f59e0b)"
    this.isCameraActive = false

    // Show file input area when camera is stopped
    this.uploadArea.style.display = "block"
  }

  capturePhoto() {
    if (!this.isCameraActive || !this.cameraVideo.videoWidth) return

    // Set canvas dimensions to match video
    this.cameraCanvas.width = this.cameraVideo.videoWidth
    this.cameraCanvas.height = this.cameraVideo.videoHeight

    // Draw video frame to canvas
    const ctx = this.cameraCanvas.getContext("2d")
    ctx.drawImage(this.cameraVideo, 0, 0)

    // Convert canvas to blob and process as file
    this.cameraCanvas.toBlob(
      (blob) => {
        // Create a file-like object from the blob
        const file = new File([blob], "camera-capture.jpg", { type: "image/jpeg" })
        this.processFile(file)

        // Stop camera after capture
        this.stopCamera()
      },
      "image/jpeg",
      0.9,
    )
  }

  handleDragOver(e) {
    e.preventDefault()
    this.uploadArea.classList.add("dragover")
  }

  handleDragLeave(e) {
    e.preventDefault()
    this.uploadArea.classList.remove("dragover")
  }

  handleDrop(e) {
    e.preventDefault()
    this.uploadArea.classList.remove("dragover")

    const files = e.dataTransfer.files
    if (files.length > 0) {
      this.processFile(files[0])
    }
  }

  handleFileSelect(e) {
    const file = e.target.files[0]
    if (file) {
      this.processFile(file)
    }
  }

  processFile(file) {
    // Validate file type
    const validTypes = ["image/jpeg", "image/jpg", "image/png", "image/webp"]
    if (!validTypes.includes(file.type)) {
      this.showError("Please select a valid image file (JPG, PNG, or WebP).")
      return
    }

    // Validate file size (max 10MB)
    if (file.size > 10 * 1024 * 1024) {
      this.showError("File size must be less than 10MB.")
      return
    }

    // Show preview
    const reader = new FileReader()
    reader.onload = (e) => {
      this.miniPreviewImg.src = e.target.result
      this.miniPreview.style.display = "block"

      this.previewImg.src = e.target.result
      this.previewImg.alt = `Preview of ${file.name}`
      this.imagePreview.style.display = "block"
      this.analyzeBtn.disabled = false
      this.hideError()

      this.updateImageInfo(file)
    }
    reader.readAsDataURL(file)
  }

  updateImageInfo(file) {
    const imageSize = document.getElementById("imageSize")
    const imageDimensions = document.getElementById("imageDimensions")

    if (imageSize) {
      imageSize.textContent = this.formatFileSize(file.size)
    }

    // Get image dimensions
    const img = new Image()
    img.onload = () => {
      if (imageDimensions) {
        imageDimensions.textContent = `${img.width} × ${img.height}`
      }
    }
    img.src = URL.createObjectURL(file)
  }

  formatFileSize(bytes) {
    if (bytes === 0) return "0 Bytes"
    const k = 1024
    const sizes = ["Bytes", "KB", "MB", "GB"]
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i]
  }

  clearImage() {
    this.imagePreview.style.display = "none"
    this.miniPreview.style.display = "none"
    this.previewImg.src = ""
    this.miniPreviewImg.src = ""
    this.fileInput.value = ""
    this.analyzeBtn.disabled = true
    this.hideResults()
    this.hideError()
    if (this.isCameraActive) {
      this.stopCamera()
    }
  }

  async analyzeImage() {
    this.showLoading()
    this.hideResults()
    this.hideError()

    try {
      await this.simulateAnalysisProgress()

      // Simulate random success/failure for demo
      if (Math.random() > 0.1) {
        // 90% success rate
        this.showResults(DEMO_DATA)
      } else {
        throw new Error("Failed to analyze image. Please try again.")
      }
    } catch (error) {
      this.showError(error.message)
    } finally {
      this.hideLoading()
    }
  }

  async simulateAnalysisProgress() {
    const steps = [
      { text: "Preparing image...", progress: 20 },
      { text: "Running AI analysis...", progress: 50 },
      { text: "Identifying food items...", progress: 75 },
      { text: "Calculating nutrition...", progress: 90 },
      { text: "Finalizing results...", progress: 100 },
    ]

    this.progressContainer.style.display = "block"

    for (const step of steps) {
      this.progressText.textContent = step.text
      this.progressFill.style.width = `${step.progress}%`
      await this.delay(400)
    }
  }

  showLoading() {
    const btnText = this.analyzeBtn.querySelector(".btn-text")
    const loadingContainer = this.analyzeBtn.querySelector(".loading-container")

    btnText.style.display = "none"
    loadingContainer.style.display = "flex"
    this.analyzeBtn.disabled = true
  }

  hideLoading() {
    const btnText = this.analyzeBtn.querySelector(".btn-text")
    const loadingContainer = this.analyzeBtn.querySelector(".loading-container")

    btnText.style.display = "block"
    loadingContainer.style.display = "none"
    this.analyzeBtn.disabled = false

    this.progressContainer.style.display = "none"
    this.progressFill.style.width = "0%"
  }

  showResults(data) {
    // Update food info
    this.foodName.textContent = data.foodName
    this.confidenceScore.textContent = `${data.confidence}%`
    this.servingSize.textContent = data.servingSize

    // Update nutrition facts
    this.updateNutritionFacts(data)

    // Create macro chart
    this.createMacroChart(data)

    // Update ingredients and allergens
    this.updateTags(this.ingredientsTags, data.ingredients, "tag")
    this.updateTags(this.allergensTags, data.allergens, "tag allergen-tag")

    // Show results
    this.resultsSection.style.display = "block"
    this.resultsSection.scrollIntoView({ behavior: "smooth" })
  }

  updateNutritionFacts(data) {
    const nutrition = this.currentView === "serving" ? data.nutritionPerServing : data.nutritionPer100g

    document.getElementById("calories").textContent = nutrition.calories
    document.getElementById("fat").textContent = nutrition.fat
    document.getElementById("carbs").textContent = nutrition.carbs
    document.getElementById("protein").textContent = nutrition.protein
    document.getElementById("sodium").textContent = nutrition.sodium
    document.getElementById("cholesterol").textContent = nutrition.cholesterol
  }

  createMacroChart(data) {
    const ctx = this.macroChart.getContext("2d")

    // Destroy existing chart if it exists
    if (this.chart) {
      this.chart.destroy()
    }

    const nutrition = this.currentView === "serving" ? data.nutritionPerServing : data.nutritionPer100g

    // Extract numeric values for chart
    const fat = Number.parseFloat(nutrition.fat)
    const carbs = Number.parseFloat(nutrition.carbs)
    const protein = Number.parseFloat(nutrition.protein)

    // Calculate calories from macros (fat: 9 cal/g, carbs: 4 cal/g, protein: 4 cal/g)
    const fatCals = fat * 9
    const carbsCals = carbs * 4
    const proteinCals = protein * 4

    this.chart = new Chart(ctx, {
      type: "doughnut",
      data: {
        labels: ["Fat", "Carbohydrates", "Protein"],
        datasets: [
          {
            data: [fatCals, carbsCals, proteinCals],
            backgroundColor: ["#ef4444", "#22d3ee", "#3b82f6"],
            borderColor: ["#dc2626", "#0891b2", "#1d4ed8"],
            borderWidth: 2,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
          legend: {
            position: "bottom",
            labels: {
              color: "#e2e8f0",
              padding: 20,
              usePointStyle: true,
            },
          },
          tooltip: {
            callbacks: {
              label: (context) => {
                const label = context.label
                const value = context.parsed
                const total = context.dataset.data.reduce((a, b) => a + b, 0)
                const percentage = ((value / total) * 100).toFixed(1)
                return `${label}: ${value} cal (${percentage}%)`
              },
            },
          },
        },
      },
    })
  }

  updateTags(container, items, className) {
    container.innerHTML = ""
    items.forEach((item) => {
      const tag = document.createElement("span")
      tag.className = className
      tag.textContent = item
      container.appendChild(tag)
    })
  }

  toggleNutritionView(e) {
    const clickedBtn = e.target
    const view = clickedBtn.dataset.view

    if (view === this.currentView) return

    // Update button states
    this.toggleBtns.forEach((btn) => btn.classList.remove("active"))
    clickedBtn.classList.add("active")

    // Update current view
    this.currentView = view

    // Update nutrition facts and chart if results are visible
    if (this.resultsSection.style.display === "block") {
      this.updateNutritionFacts(DEMO_DATA)
      this.createMacroChart(DEMO_DATA)
    }
  }

  showError(message) {
    this.errorMessage.textContent = message
    this.errorSection.style.display = "block"
    this.errorSection.scrollIntoView({ behavior: "smooth" })
  }

  hideError() {
    this.errorSection.style.display = "none"
  }

  hideResults() {
    this.resultsSection.style.display = "none"
  }

  delay(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms))
  }
}

// Initialize the app when DOM is loaded
document.addEventListener("DOMContentLoaded", () => {
  new FoodRecognitionApp()
})
