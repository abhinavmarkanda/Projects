import React, { useState } from "react";
import { medinjury_backend } from "../../../declarations/medinjury_backend";

function App() {
  const [file, setFile] = useState(null);
  const [output, setOutput] = useState("");

  const handleUpload = async () => {
    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64 = reader.result.split(",")[1];
      const result = await medinjury_backend.analyze_image({ base64_image: base64 });
      setOutput(result);
    };
    reader.readAsDataURL(file);
  };

  return (
    <div>
      <input type="file" onChange={(e) => setFile(e.target.files[0])} />
      <button onClick={handleUpload}>Analyze Image</button>
      {output && <p>ML Output: {output}</p>}
    </div>
  );
}

export default App;