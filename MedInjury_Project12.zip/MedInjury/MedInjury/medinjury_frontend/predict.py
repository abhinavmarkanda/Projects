import sys
import base64
from PIL import Image
import io

def predict(image_data):
    image = Image.open(io.BytesIO(base64.b64decode(image_data)))
    return "Injury Type: Fracture (Example output)"

if __name__ == "__main__":
    base64_img = sys.argv[1]
    print(predict(base64_img))