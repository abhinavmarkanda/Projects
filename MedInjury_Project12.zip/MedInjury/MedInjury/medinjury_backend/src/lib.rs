use ic_cdk::api::call::call;
use ic_cdk_macros::*;
use serde::{Deserialize, Serialize};

#[derive(Serialize, Deserialize)]
struct ImageUpload {
    base64_image: String,
}

#[update]
async fn analyze_image(image: ImageUpload) -> String {
    let output = std::process::Command::new("python3")
        .arg("predict.py")
        .arg(&image.base64_image)
        .output()
        .expect("Failed to run Python script");

    let result = String::from_utf8_lossy(&output.stdout).to_string();
    result
}