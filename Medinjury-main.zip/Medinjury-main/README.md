# Hackowasp7.0
hackathon code for medinjury by CodeNirvana
##Team Members 
- Pulkit Goyal: website Developer
- Lavanya Garg: Website Developer
- Abhinav Markanda: Designer
- Arpit Goel: Python Developer(AI/ML)
- Heaven: Website Developer
